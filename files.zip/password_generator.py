import tkinter as tk
from tkinter import messagebox
import secrets
import string
import pyperclip

# -----------------------------
# Character Sets
# -----------------------------
UPPER = string.ascii_uppercase
LOWER = string.ascii_lowercase
DIGITS = string.digits
SYMBOLS = "!@#$%^&*()-_=+[]{};:,.<>?/"

AMBIGUOUS = "0O1lI"

history = []


# -----------------------------
# Password Strength
# -----------------------------
def password_strength(length, types):
    score = 0

    if length >= 8:
        score += 1
    if length >= 12:
        score += 1
    if length >= 16:
        score += 1

    score += types

    if score <= 3:
        return "Weak", "red"
    elif score <= 5:
        return "Medium", "orange"
    else:
        return "Strong", "green"


# -----------------------------
# Generate Password
# -----------------------------
def generate_password():

    length = length_var.get()

    if length < 8:
        messagebox.showerror("Error", "Password length must be at least 8.")
        return

    pools = []

    upper = upper_var.get()
    lower = lower_var.get()
    digit = digit_var.get()
    symbol = symbol_var.get()

    selected = sum([upper, lower, digit, symbol])

    if selected < 2:
        messagebox.showerror(
            "Error",
            "Select at least TWO character types."
        )
        return

    exclude = exclude_var.get()

    upper_chars = UPPER
    lower_chars = LOWER
    digit_chars = DIGITS
    symbol_chars = SYMBOLS

    if exclude:
        upper_chars = ''.join(c for c in upper_chars if c not in AMBIGUOUS)
        lower_chars = ''.join(c for c in lower_chars if c not in AMBIGUOUS)
        digit_chars = ''.join(c for c in digit_chars if c not in AMBIGUOUS)

    password = []

    if upper:
        password.append(secrets.choice(upper_chars))
        pools.extend(upper_chars)

    if lower:
        password.append(secrets.choice(lower_chars))
        pools.extend(lower_chars)

    if digit:
        password.append(secrets.choice(digit_chars))
        pools.extend(digit_chars)

    if symbol:
        password.append(secrets.choice(symbol_chars))
        pools.extend(symbol_chars)

    while len(password) < length:
        password.append(secrets.choice(pools))

    secrets.SystemRandom().shuffle(password)

    final_password = "".join(password)

    password_entry.delete(0, tk.END)
    password_entry.insert(0, final_password)

    pyperclip.copy(final_password)

    strength, color = password_strength(length, selected)

    strength_label.config(
        text=f"Strength: {strength}",
        fg=color
    )

    history.insert(0, final_password)

    if len(history) > 5:
        history.pop()

    history_box.delete(0, tk.END)

    for item in history:
        history_box.insert(tk.END, item)


# -----------------------------
# Copy Password
# -----------------------------
def copy_password():
    pwd = password_entry.get()

    if pwd:
        pyperclip.copy(pwd)
        messagebox.showinfo("Copied", "Password copied to clipboard.")


# -----------------------------
# GUI
# -----------------------------
root = tk.Tk()
root.title("Advanced Random Password Generator")
root.geometry("500x620")
root.resizable(False, False)

title = tk.Label(
    root,
    text="Random Password Generator",
    font=("Arial", 18, "bold")
)
title.pack(pady=10)

length_var = tk.IntVar(value=12)

tk.Label(root, text="Password Length").pack()

length_spin = tk.Spinbox(
    root,
    from_=8,
    to=64,
    textvariable=length_var,
    width=10
)
length_spin.pack()

upper_var = tk.BooleanVar(value=True)
lower_var = tk.BooleanVar(value=True)
digit_var = tk.BooleanVar(value=True)
symbol_var = tk.BooleanVar(value=True)
exclude_var = tk.BooleanVar()

tk.Checkbutton(
    root,
    text="Uppercase Letters",
    variable=upper_var
).pack(anchor="w", padx=30)

tk.Checkbutton(
    root,
    text="Lowercase Letters",
    variable=lower_var
).pack(anchor="w", padx=30)

tk.Checkbutton(
    root,
    text="Numbers",
    variable=digit_var
).pack(anchor="w", padx=30)

tk.Checkbutton(
    root,
    text="Symbols",
    variable=symbol_var
).pack(anchor="w", padx=30)

tk.Checkbutton(
    root,
    text="Exclude Ambiguous Characters (0 O l 1 I)",
    variable=exclude_var
).pack(anchor="w", padx=30, pady=5)

generate_btn = tk.Button(
    root,
    text="Generate Password",
    command=generate_password,
    bg="lightgreen",
    width=25
)
generate_btn.pack(pady=10)

password_entry = tk.Entry(
    root,
    font=("Arial", 14),
    width=35
)
password_entry.pack()

copy_btn = tk.Button(
    root,
    text="Copy to Clipboard",
    command=copy_password,
    width=20
)
copy_btn.pack(pady=10)

strength_label = tk.Label(
    root,
    text="Strength: ",
    font=("Arial", 12, "bold")
)
strength_label.pack()

tk.Label(
    root,
    text="Last 5 Generated Passwords",
    font=("Arial", 12, "bold")
).pack(pady=10)

history_box = tk.Listbox(
    root,
    width=50,
    height=8
)
history_box.pack()

root.mainloop()
