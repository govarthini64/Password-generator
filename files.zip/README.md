# Advanced Random Password Generator

A desktop password generator built with Python's `tkinter` GUI toolkit. Generates
cryptographically secure random passwords using the `secrets` module, shows a
strength rating, copies results to the clipboard, and keeps a short history of
recently generated passwords.

## Features

- Adjustable password length (8–64 characters)
- Toggle character sets: uppercase, lowercase, numbers, symbols
- Option to exclude visually ambiguous characters (`0 O 1 l I`)
- Cryptographically secure generation via Python's `secrets` module
- Automatic clipboard copy on generation, plus a manual "Copy to Clipboard" button
- Live password strength rating (Weak / Medium / Strong)
- History panel showing the last 5 generated passwords

## Requirements

- Python 3.7+
- Dependencies listed in `requirements.txt`

Install dependencies:

```bash
pip install -r requirements.txt
```

> Note: `tkinter` ships with most standard Python installations. On some Linux
> distributions you may need to install it separately, e.g.
> `sudo apt-get install python3-tk`.

## Usage

Run the app:

```bash
python password_generator.py
```

1. Set the desired password length using the spinbox.
2. Check/uncheck the character types you want included (at least two required).
3. Optionally enable "Exclude Ambiguous Characters".
4. Click **Generate Password** — the password appears in the entry field, is
   copied to your clipboard automatically, and its strength is displayed.
5. Use **Copy to Clipboard** at any time to re-copy the currently shown password.
6. The last 5 generated passwords are listed at the bottom of the window.

## Project Structure

```
password-generator/
├── password_generator.py   # Main application
├── requirements.txt        # Python dependencies
└── README.md                # Project documentation
```

## License

Free to use and modify for personal or educational purposes.
